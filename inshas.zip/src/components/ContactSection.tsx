/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { MessageSquare, Instagram, Facebook, Mail, Phone, Send, Sparkles, Check, CheckCircle2 } from "lucide-react";

export default function ContactSection() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const submissions = JSON.parse(localStorage.getItem("inshas_contact_queries") || "[]");
      submissions.push({
        name,
        email,
        message,
        date: new Date().toISOString()
      });
      localStorage.setItem("inshas_contact_queries", JSON.stringify(submissions));

      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  const getWhatsAppQueryLink = () => {
    const text = `Assalamu Alaikum Inshas! 🌸\n\nI have a general query from your website.\n\n*My Details:*\n• *Name:* ${name}\n• *Email:* ${email}\n\n*Message:* ${message}\n\nLooking forward to hearing from you. Thank you!`;
    return `https://wa.me/923004971580?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32 bg-brand-black border-t border-white/5 overflow-hidden">
      {/* Glow backgrounds */}
      <div className="absolute top-[30%] left-[-15%] w-[400px] h-[400px] rounded-full bg-luxury-pink/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[350px] h-[350px] rounded-full bg-white/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section title */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-24">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 text-luxury-pink mb-4"
          >
            <Sparkles size={14} className="animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
              Connect With Us
            </span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white mb-6"
          >
            We'd Love to Hear From You
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-white/60 font-light text-sm sm:text-base leading-relaxed"
          >
            Whether you have questions about our individual collections, custom corporate gifts, or wholesale inquiries, our team is here to assist.
          </motion.p>
        </div>

        {/* Contact layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 sm:gap-16 items-stretch">
          
          {/* Left Block: Social Launchers & Direct Channels */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              <h3 className="font-serif text-2xl font-bold text-white leading-tight">
                Direct Channels
              </h3>
              <p className="text-white/60 font-light text-xs sm:text-sm leading-relaxed">
                Connect with our team instantly on social media or send an email directly to our partnerships coordinator. We respond within 1 business hour.
              </p>

              {/* Channel list */}
              <div className="space-y-4 pt-2">
                {/* Email link */}
                <a
                  href="mailto:partnerships@inshas.pk"
                  className="flex items-center space-x-4 p-4 rounded-2xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.03] hover:border-luxury-pink/20 transition-all duration-300 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/5 group-hover:bg-luxury-pink/10 border border-white/10 group-hover:border-luxury-pink/20 flex items-center justify-center transition-all duration-300">
                    <Mail size={18} className="text-white group-hover:text-luxury-pink transition-colors" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Email Inquiries</span>
                    <span className="text-xs sm:text-sm font-medium text-white/90 group-hover:text-luxury-pink transition-colors">partnerships@inshas.pk</span>
                  </div>
                </a>

                {/* Phone support */}
                <div className="flex items-center space-x-4 p-4 rounded-2xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.03] transition-all duration-300 group">
                  <div className="w-10 h-10 rounded-xl bg-white/5 group-hover:bg-luxury-pink/10 border border-white/10 flex items-center justify-center">
                    <Phone size={18} className="text-white" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Official Support</span>
                    <span className="text-xs sm:text-sm font-medium text-white/90">+92-300-INSHAS</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Social launchers */}
            <div className="space-y-4 pt-6 border-t border-white/5">
              <span className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">
                Social Elevators:
              </span>

              <div className="flex flex-col sm:flex-row gap-3">
                {/* Chat on WhatsApp Button */}
                <a
                  href="https://wa.me/923004971580?text=Salam%20Inshas!%20%F0%9F%8E%80%20I%20would%20love%20to%20know%20more%20about%20your%20gifting%20products."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 text-xs uppercase tracking-widest bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-4 rounded-full shadow-lg transition-colors flex items-center justify-center space-x-2.5 cursor-pointer"
                >
                  <MessageSquare size={14} />
                  <span>Chat on WhatsApp</span>
                </a>

                {/* Follow on Instagram Button */}
                <a
                  href="https://instagram.com/inshas.pk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 text-xs uppercase tracking-widest border border-white/10 hover:border-luxury-pink/40 text-white/80 hover:text-luxury-pink bg-white/5 hover:bg-luxury-pink/5 font-semibold px-6 py-4 rounded-full transition-all flex items-center justify-center space-x-2.5 cursor-pointer"
                >
                  <Instagram size={14} />
                  <span>Follow on Instagram</span>
                </a>
              </div>

              {/* Facebook auxiliary link */}
              <a
                href="https://facebook.com/inshas.pk"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-white/40 hover:text-white/80 flex items-center justify-center sm:justify-start space-x-2 pl-4 pt-1 transition-colors group"
              >
                <Facebook size={12} className="group-hover:text-luxury-pink transition-colors" />
                <span>Visit Facebook Community</span>
              </a>
            </div>
          </div>

          {/* Right Block: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="p-8 rounded-[2rem] border border-white/10 bg-[#1a1a1a] shadow-2xl relative overflow-hidden h-full flex flex-col justify-center">
              
              {!isSuccess ? (
                <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
                  <div className="space-y-1">
                    <h3 className="font-serif text-2xl font-bold text-white">Send a Direct Message</h3>
                    <p className="text-xs text-white/50">Our team will coordinate with you via email or WhatsApp.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/70">Your Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Zainab Riaz"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs text-white/70">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="e.g. zainab@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/70">Your Message *</label>
                    <textarea
                      required
                      placeholder="Write your custom inquiry, feedback or gift request here..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={4}
                      className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full text-xs uppercase tracking-widest bg-white hover:bg-luxury-pink text-brand-black font-bold py-4 rounded-full transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg disabled:opacity-50 cursor-pointer hover:-translate-y-0.5"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-brand-black border-t-transparent rounded-full animate-spin" />
                        <span>Sending Message...</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>Submit Message</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center space-y-6 relative z-10"
                >
                  <div className="w-16 h-16 rounded-full bg-luxury-pink/15 border border-luxury-pink flex items-center justify-center mx-auto text-luxury-pink animate-bounce">
                    <CheckCircle2 size={32} />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-serif text-2xl font-bold text-white">Inquiry Forwarded!</h3>
                    <p className="text-xs text-white/50 font-light leading-relaxed">
                      Thank you for contacting Inshas. Your message has been saved in our local logs, and our customer response team will reach out within 1 business hour.
                    </p>
                  </div>

                  {/* Real WhatsApp Query Bypass */}
                  <div className="p-4 rounded-xl bg-luxury-pink/5 border border-luxury-pink/10 max-w-sm mx-auto space-y-3">
                    <span className="text-[10px] uppercase tracking-widest text-luxury-pink font-bold block">
                      Fast-Track via WhatsApp Chat
                    </span>
                    <p className="text-[10px] text-white/50 leading-relaxed">
                      Want to discuss immediately? Send this pre-filled message directly to our active WhatsApp line!
                    </p>
                    <a
                      href={getWhatsAppQueryLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-2 text-xs uppercase tracking-widest bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold px-6 py-3 rounded-full shadow-md w-full"
                    >
                      <MessageSquare size={14} />
                      <span>Instant WhatsApp Query</span>
                    </a>
                  </div>

                  <button
                    onClick={() => {
                      setName("");
                      setEmail("");
                      setMessage("");
                      setIsSuccess(false);
                    }}
                    className="text-xs text-white/30 hover:text-white underline block mx-auto pt-2"
                  >
                    Send Another Message
                  </button>
                </motion.div>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
