/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { Award, Feather, Truck, ShieldCheck, Heart, Sparkles, HelpCircle } from "lucide-react";
import { ADVANTAGES } from "../data";

// Match icons with indices
const ICONS = [
  <Award className="w-6 h-6 text-luxury-pink" />,
  <Feather className="w-6 h-6 text-luxury-pink" />,
  <Truck className="w-6 h-6 text-luxury-pink" />,
  <HelpCircle className="w-6 h-6 text-luxury-pink" />,
  <Heart className="w-6 h-6 text-luxury-pink" />,
  <ShieldCheck className="w-6 h-6 text-luxury-pink" />
];

export default function WhyChoose() {
  return (
    <section
      id="why-choose"
      className="relative py-24 bg-brand-black border-t border-white/5 overflow-hidden"
    >
      {/* Decorative Blur Spheres */}
      <div className="absolute top-[50%] left-[-10%] w-[300px] h-[300px] rounded-full bg-luxury-pink/5 blur-[90px] pointer-events-none" />
      <div className="absolute top-[20%] right-[-10%] w-[250px] h-[250px] rounded-full bg-white/5 blur-[80px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 text-luxury-pink mb-4"
          >
            <Sparkles size={14} className="animate-spin-slow" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
              The Inshas Promise
            </span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white mb-6"
          >
            Why Choose Inshas
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-white/60 font-light text-sm sm:text-base leading-relaxed"
          >
            We align fine engineering with a warm passion for hospitality, delivering products and gifting services that inspire absolute peace of mind.
          </motion.p>
        </div>

        {/* Bento Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {ADVANTAGES.map((advantage, index) => (
            <motion.div
              key={advantage.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.08 }}
              whileHover={{ y: -6, transition: { duration: 0.2 } }}
              className="group p-8 rounded-3xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.03] hover:border-luxury-pink/20 transition-all duration-300 backdrop-blur-sm relative overflow-hidden"
            >
              {/* Subtle background glow on card hover */}
              <div className="absolute inset-0 bg-gradient-to-tr from-luxury-pink/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="space-y-5 relative z-10">
                {/* Icon wrapper with hover pulse */}
                <div className="w-12 h-12 rounded-2xl bg-white/5 group-hover:bg-luxury-pink/10 border border-white/10 group-hover:border-luxury-pink/30 flex items-center justify-center transition-colors duration-300">
                  {ICONS[index] || <Sparkles className="w-6 h-6 text-luxury-pink" />}
                </div>

                <div className="space-y-2">
                  <h3 className="font-serif text-lg font-bold text-white group-hover:text-luxury-pink transition-colors duration-300">
                    {advantage.title}
                  </h3>
                  <p className="text-white/60 text-xs sm:text-sm font-light leading-relaxed">
                    {advantage.description}
                  </p>
                </div>
              </div>

              {/* Minimal aesthetic accent line in corner */}
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-luxury-pink transition-all duration-300 group-hover:w-16" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
