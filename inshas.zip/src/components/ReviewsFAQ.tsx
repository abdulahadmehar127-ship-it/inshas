/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Star, MessageSquare, ChevronDown, Sparkles, HelpCircle, UserCheck } from "lucide-react";
import { REVIEWS, FAQS } from "../data";

export default function ReviewsFAQ() {
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  const toggleFaq = (id: string) => {
    setOpenFaq(openFaq === id ? null : id);
  };

  return (
    <section id="faq" className="relative py-24 sm:py-32 bg-brand-black border-t border-white/5 overflow-hidden">
      {/* Soft gradient spotlights */}
      <div className="absolute top-[40%] right-[-10%] w-[350px] h-[350px] rounded-full bg-luxury-pink/5 blur-[90px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[-10%] w-[300px] h-[300px] rounded-full bg-white/[0.02] blur-[80px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-20">
          
          {/* Left Column: Customer Testimonials */}
          <div className="lg:col-span-5 space-y-10">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 text-luxury-pink">
                <Star size={14} className="fill-luxury-pink" />
                <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
                  Verified Reviews
                </span>
              </div>
              <h2 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                What Our Customers Say
              </h2>
              <p className="text-white/60 font-light text-xs sm:text-sm leading-relaxed max-w-sm">
                Real feedback from real homes. Experience the tactile difference that makes Inshas a treasured addition to everyday life.
              </p>
            </div>

            {/* Testimonials Stack */}
            <div className="space-y-6">
              {REVIEWS.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="p-6 rounded-2xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.02] hover:border-luxury-pink/15 transition-all duration-300 relative"
                >
                  {/* Rating Stars */}
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} size={14} className="text-luxury-pink fill-luxury-pink" />
                    ))}
                  </div>

                  {/* Feedback Text */}
                  <p className="text-white/80 font-light italic text-xs sm:text-sm leading-relaxed mb-4">
                    "{review.text}"
                  </p>

                  {/* User info */}
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-white font-semibold font-serif tracking-wide">{review.author}</span>
                    <span className="text-white/40 font-mono">{review.location} • {review.date}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Column: FAQs Accordion */}
          <div className="lg:col-span-7 space-y-10">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 text-luxury-pink">
                <HelpCircle size={14} />
                <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
                  Common Questions
                </span>
              </div>
              <h2 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                Frequently Asked Questions
              </h2>
              <p className="text-white/60 font-light text-xs sm:text-sm leading-relaxed">
                Everything you need to know about our nationwide delivery service, payment options, and partnership operations.
              </p>
            </div>

            {/* Accordion List */}
            <div className="space-y-4">
              {FAQS.map((faq, index) => {
                const isOpen = openFaq === faq.id;
                return (
                  <motion.div
                    key={faq.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                    className="border border-white/5 rounded-2xl overflow-hidden bg-white/[0.01] hover:bg-white/[0.02] transition-colors"
                  >
                    <button
                      onClick={() => toggleFaq(faq.id)}
                      className="w-full flex items-center justify-between p-6 text-left focus:outline-none group cursor-pointer"
                    >
                      <span className="font-serif text-xs sm:text-sm font-bold text-white group-hover:text-luxury-pink transition-colors pr-4">
                        {faq.question}
                      </span>
                      <div className={`w-8 h-8 rounded-full border border-white/10 flex items-center justify-center shrink-0 group-hover:border-luxury-pink/30 group-hover:bg-luxury-pink/5 transition-colors ${isOpen ? "border-luxury-pink text-luxury-pink rotate-180" : "text-white/40"}`}>
                        <ChevronDown size={14} className="transition-transform duration-300" />
                      </div>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3, ease: "easeInOut" }}
                          className="border-t border-white/[0.03] overflow-hidden bg-brand-black/40"
                        >
                          <p className="p-6 text-xs sm:text-sm text-white/70 font-light leading-relaxed whitespace-pre-line">
                            {faq.answer}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
