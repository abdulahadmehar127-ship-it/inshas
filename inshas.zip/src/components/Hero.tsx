/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ArrowDown, ArrowRight, Sparkles } from "lucide-react";
import { HERO_IMAGE } from "../data";

interface HeroProps {
  onScrollToSection: (sectionId: string) => void;
  onOpenPartnerModal: () => void;
}

export default function Hero({ onScrollToSection, onOpenPartnerModal }: HeroProps) {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Premium Lifestyle Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_IMAGE}
          alt="Inshas Luxury Lifestyle"
          className="w-full h-full object-cover object-center scale-105 animate-pulse-slow"
          referrerPolicy="no-referrer"
          style={{
            animationDuration: "12s",
            filter: "brightness(0.35) contrast(1.05)",
          }}
        />
        {/* Soft luxury color overlays for warm glow */}
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-brand-black/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-black/90 via-brand-black/30 to-transparent" />
        <div className="absolute -top-[30%] -left-[20%] w-[60%] h-[80%] rounded-full bg-luxury-pink/10 blur-[120px] pointer-events-none" />
        <div className="absolute -bottom-[20%] -right-[10%] w-[50%] h-[70%] rounded-full bg-luxury-pink/5 blur-[100px] pointer-events-none" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center lg:text-left w-full pt-16 md:pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="inline-flex items-center space-x-2 bg-white/5 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full mb-8"
        >
          <Sparkles size={14} className="text-luxury-pink animate-spin-slow" />
          <span className="text-[10px] uppercase tracking-[0.25em] text-white/80 font-medium">
            Pakistani Luxury Brand
          </span>
        </motion.div>

        {/* Headings */}
        <div className="space-y-4 mb-8">
          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
            className="font-serif italic font-light tracking-wide text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white/90 leading-tight"
          >
            Premium Lifestyle Products,
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="font-serif font-bold tracking-tight text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-white leading-[1.1]"
          >
            Designed to Make <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-luxury-pink to-white/90">Everyday Moments</span> Beautiful.
          </motion.h2>
        </div>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
          className="text-base sm:text-lg md:text-xl text-white/70 max-w-2xl font-light leading-relaxed mb-12 mx-auto lg:mx-0"
        >
          Discover beautifully crafted products that combine elegance, comfort, and functionality. Whether for personal use or thoughtful gifting, Inshas brings premium lifestyle essentials designed to enrich everyday living.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 sm:gap-6"
        >
          <button
            onClick={() => onScrollToSection("products")}
            className="w-full sm:w-auto text-xs uppercase tracking-widest bg-luxury-pink hover:bg-luxury-pink-dark text-brand-black font-semibold px-8 py-4 rounded-full transition-all duration-300 shadow-xl shadow-luxury-pink/10 hover:shadow-luxury-pink/20 hover:-translate-y-1 flex items-center justify-center space-x-2 group cursor-pointer"
          >
            <span>Shop Now</span>
            <ArrowRight size={14} className="transform group-hover:translate-x-1 transition-transform duration-300" />
          </button>
          <button
            onClick={onOpenPartnerModal}
            className="w-full sm:w-auto text-xs uppercase tracking-widest border border-white/20 hover:border-luxury-pink text-white/90 hover:text-luxury-pink bg-white/5 hover:bg-luxury-pink/5 font-semibold px-8 py-4 rounded-full transition-all duration-300 hover:-translate-y-1 flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>Become a Retail Partner</span>
          </button>
        </motion.div>
      </div>

      {/* Floating Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center cursor-pointer group"
        onClick={() => onScrollToSection("about")}
      >
        <span className="text-[9px] uppercase tracking-[0.4em] text-white/40 group-hover:text-luxury-pink transition-colors duration-300 mb-2">
          Scroll Down
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
          className="text-white/40 group-hover:text-luxury-pink transition-colors duration-300"
        >
          <ArrowDown size={16} />
        </motion.div>
      </motion.div>
    </section>
  );
}
