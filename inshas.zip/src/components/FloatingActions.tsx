/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, ArrowUp, X, Sparkles, Send } from "lucide-react";

interface FloatingActionsProps {
  onScrollToSection: (sectionId: string) => void;
  onOpenPartnerModal: () => void;
}

export default function FloatingActions({ onScrollToSection, onOpenPartnerModal }: FloatingActionsProps) {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showConcierge, setShowConcierge] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const getWhatsAppLink = (message: string) => {
    return `https://wa.me/923004971580?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end space-y-4 pointer-events-none">
      
      {/* WhatsApp Floating Concierge Chat Window */}
      <AnimatePresence>
        {showConcierge && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 15 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="w-[320px] bg-brand-black/95 backdrop-blur-md border border-white/10 rounded-[1.5rem] shadow-2xl overflow-hidden pointer-events-auto flex flex-col mb-2"
          >
            {/* Header */}
            <div className="bg-[#181818] p-4 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full bg-luxury-pink/15 flex items-center justify-center border border-luxury-pink/20">
                    <span className="font-serif text-sm font-bold text-luxury-pink">I</span>
                  </div>
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-brand-black" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-1">
                    <span>Inshas Concierge</span>
                    <Sparkles size={10} className="text-luxury-pink animate-pulse" />
                  </h4>
                  <p className="text-[9px] text-emerald-400 font-medium">Online • Responds in 5m</p>
                </div>
              </div>
              <button
                onClick={() => setShowConcierge(false)}
                className="p-1 rounded-full hover:bg-white/5 text-white/40 hover:text-white transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            {/* Chat Body */}
            <div className="p-4 space-y-3 max-h-[250px] overflow-y-auto">
              <div className="bg-white/5 border border-white/5 p-3 rounded-2xl rounded-tl-none max-w-[85%] text-xs text-white/95 leading-relaxed">
                Assalamu Alaikum! 🌸 Welcome to Inshas Premium Lifestyle. How can we elevate your space or assist your gifting needs today?
              </div>
            </div>

            {/* Quick Actions Footer */}
            <div className="p-4 pt-0 border-t border-white/5 bg-[#141414] space-y-2">
              <span className="text-[8px] uppercase tracking-wider text-white/30 font-semibold block mb-1">
                Select an Instant Request:
              </span>
              
              <a
                href={getWhatsAppLink("Salam Inshas! 🛍️ I would like to place an order from your premium website collections.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-left text-[11px] px-3.5 py-2.5 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-luxury-pink/10 hover:border-luxury-pink/25 hover:text-luxury-pink text-white/80 transition-all block font-medium"
              >
                Place a Product Order 🛍️
              </a>

              <button
                onClick={() => {
                  setShowConcierge(false);
                  onOpenPartnerModal();
                }}
                className="w-full text-left text-[11px] px-3.5 py-2.5 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-luxury-pink/10 hover:border-luxury-pink/25 hover:text-luxury-pink text-white/80 transition-all block font-medium pointer-events-auto"
              >
                Become a Retail Partner 🤝
              </button>

              <a
                href={getWhatsAppLink("Salam Inshas! 💬 I have a general query regarding shipping, warranty or corporate orders.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-left text-[11px] px-3.5 py-2.5 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-luxury-pink/10 hover:border-luxury-pink/25 hover:text-luxury-pink text-white/80 transition-all block font-medium"
              >
                Ask a General Question 💬
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Launcher Buttons Container */}
      <div className="flex items-center space-x-3 pointer-events-auto">
        {/* Scroll To Top Button */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, x: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.8, x: 20 }}
              onClick={handleScrollTop}
              className="w-12 h-12 rounded-full border border-white/10 bg-brand-black/85 backdrop-blur-md flex items-center justify-center text-white/70 hover:text-luxury-pink hover:border-luxury-pink/30 shadow-xl transition-all hover:-translate-y-0.5 cursor-pointer"
              title="Scroll to Top"
            >
              <ArrowUp size={18} />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Floating WhatsApp Button */}
        <motion.button
          onClick={() => setShowConcierge(!showConcierge)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="w-14 h-14 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-2xl cursor-pointer hover:bg-emerald-600 transition-colors relative"
          title="Inshas Concierge Support"
        >
          {showConcierge ? (
            <X size={24} />
          ) : (
            <>
              <MessageSquare size={24} className="fill-white/10" />
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-luxury-pink rounded-full border-2 border-brand-black flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              </span>
            </>
          )}
        </motion.button>
      </div>

    </div>
  );
}
