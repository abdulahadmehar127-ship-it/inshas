/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { Quote, Sparkles } from "lucide-react";

export default function About() {
  return (
    <section
      id="about"
      className="relative py-24 sm:py-32 bg-brand-black overflow-hidden border-t border-white/5"
    >
      {/* Background Soft Gradients */}
      <div className="absolute top-[20%] right-[-10%] w-[400px] h-[400px] rounded-full bg-luxury-pink/5 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[-10%] w-[350px] h-[350px] rounded-full bg-white/5 blur-[80px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Section Left Column: Artistic Branding Accent */}
          <div className="lg:col-span-5 space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="flex items-center space-x-2 text-luxury-pink"
            >
              <Sparkles size={16} />
              <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
                Our Heritage & Mission
              </span>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight"
            >
              About <span className="italic font-light text-luxury-pink block sm:inline">Inshas</span>
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm"
            >
              <Quote className="absolute -top-4 -left-4 text-luxury-pink/30 w-12 h-12" />
              <p className="font-serif italic text-lg text-white/90 leading-relaxed relative z-10">
                "We believe that the items you interact with daily should not only serve a purpose, but also inspire a feeling of beauty and simple joy."
              </p>
              <div className="mt-4 flex items-center space-x-2">
                <div className="w-6 h-[1px] bg-luxury-pink" />
                <span className="text-[9px] uppercase tracking-widest text-white/50 font-mono">
                  The Inshas Design Studio
                </span>
              </div>
            </motion.div>
          </div>

          {/* Section Right Column: Storytelling Paragraphs */}
          <div className="lg:col-span-7 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="space-y-6 text-white/70 text-base sm:text-lg font-light leading-relaxed"
            >
              <p>
                Inshas is a Pakistani premium lifestyle brand committed to creating elegant products that improve everyday experiences. We are driven by the belief that luxury isn't about excess—it is about clean aesthetics, uncompromising quality, and delightful utility.
              </p>
              
              <div className="border-l-2 border-luxury-pink pl-6 py-2 my-4">
                <span className="text-[11px] uppercase tracking-[0.25em] text-luxury-pink font-semibold block mb-2">
                  Our Mission is Simple:
                </span>
                <p className="font-serif text-white text-lg sm:text-xl font-medium tracking-tight">
                  To combine beautiful design, premium quality, and practical functionality into products people truly enjoy using and gifting.
                </p>
              </div>

              <p>
                Every single product in our catalog is meticulously sourced, refined, and rigorously tested to ensure it meets modern international expectations of durability, exceptional tactile comfort, and timeless minimalist appeal.
              </p>

              <p>
                Whether you are enhancing your personal home sanctuary or seeking an elegant, deeply thoughtful gift for someone you cherish, Inshas brings Pakistani homes the premium aesthetics typically reserved for luxury international markets.
              </p>
            </motion.div>

            {/* Micro details counter */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="grid grid-cols-3 gap-6 pt-6 border-t border-white/5"
            >
              <div>
                <span className="block font-serif text-3xl font-bold text-white">100%</span>
                <span className="text-[9px] uppercase tracking-widest text-white/40 block mt-1">Premium Quality</span>
              </div>
              <div>
                <span className="block font-serif text-3xl font-bold text-white">PK</span>
                <span className="text-[9px] uppercase tracking-widest text-white/40 block mt-1">Sourced with Pride</span>
              </div>
              <div>
                <span className="block font-serif text-3xl font-bold text-white">24/7</span>
                <span className="text-[9px] uppercase tracking-widest text-white/40 block mt-1">WhatsApp Concierge</span>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
