/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, Download, FileText, Send, Building, ShieldAlert, Sparkles, MessageSquare, ChevronLeft, ChevronRight, X, PhoneCall } from "lucide-react";
import { RetailApplication } from "../types";

interface PartnershipProps {
  isModalOpen: boolean;
  onCloseModal: () => void;
}

export default function RetailPartnership({ isModalOpen, onCloseModal }: PartnershipProps) {
  // Partnership application state
  const [storeName, setStoreName] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [storeType, setStoreType] = useState("Bookstore");
  const [message, setMessage] = useState("");
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Interactive Digital Catalog Reader State
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [catalogPage, setCatalogPage] = useState(1);

  const benefits = [
    "Attractive Wholesale Pricing",
    "Premium Packaging",
    "Fast Supply",
    "Marketing Support",
    "Reliable Inventory",
    "Dedicated Business Support"
  ];

  const catalogSlides = [
    {
      page: 1,
      title: "INSHAS",
      subtitle: "WHOLESALE CATALOGUE • 2026",
      tagline: "Designed for Everyday Elegance",
      description: "A comprehensive look at our premium product catalog, distribution structure, and white-glove logistics across Pakistan.",
      badge: "Confidential"
    },
    {
      page: 2,
      title: "Wholesale Margin Sheet",
      subtitle: "RECOMMENDED MARGINS & MOQ",
      tagline: "High Profitability, High Conversion",
      description: "• Rechargeable Reading Light: MOQ 20 units • Retail PKR 3,450 • Retailer Margin: 35%\n• Crystal Night Lamp: MOQ 15 units • Retail PKR 4,850 • Retailer Margin: 40%\n• Double-digit tier margins available for orders exceeding 100+ units.",
      badge: "Partners Only"
    },
    {
      page: 3,
      title: "Logistics & Brand Support",
      subtitle: "NATIONWIDE SUPPLY CHAIN",
      tagline: "White-Glove Distribution & Merchandising",
      description: "• Guaranteed next-day dispatch from our central Lahore fulfillment hub.\n• All stock shipped in pristine, triple-layer custom brand master cartons.\n• Professional POS product stands & aesthetic posters provided free of charge.",
      badge: "Support"
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const applicationId = "PART-" + Math.floor(1000 + Math.random() * 9000);

    setTimeout(() => {
      const application: RetailApplication = {
        id: applicationId,
        storeName,
        contactPerson,
        email,
        phone,
        city,
        storeType,
        message,
        submittedAt: new Date().toISOString()
      };

      // Save application to localStorage for durable local persistence
      const currentApps = JSON.parse(localStorage.getItem("inshas_partnerships") || "[]");
      currentApps.push(application);
      localStorage.setItem("inshas_partnerships", JSON.stringify(currentApps));

      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  const getWhatsAppPartnerLink = () => {
    const text = `Assalamu Alaikum Inshas! 🌸\n\nI am interested in becoming an official retail partner.\n\n*Store Information:*\n• *Store Name:* ${storeName}\n• *Contact Person:* ${contactPerson}\n• *Store Type:* ${storeType}\n• *City:* ${city}\n• *Phone:* ${phone}\n• *Email:* ${email}\n\n*Inquiry Message:* ${message || "I would love to receive wholesale pricing structures and catalogs."}\n\nLooking forward to a mutually beneficial partnership!\n\nBest regards,\n${contactPerson}`;
    return `https://wa.me/923004971580?text=${encodeURIComponent(text)}`;
  };

  const handleNextPage = () => {
    setCatalogPage((prev) => Math.min(catalogSlides.length, prev + 1));
  };

  const handlePrevPage = () => {
    setCatalogPage((prev) => Math.max(1, prev - 1));
  };

  const resetForm = () => {
    setStoreName("");
    setContactPerson("");
    setEmail("");
    setPhone("");
    setCity("");
    setStoreType("Bookstore");
    setMessage("");
    setIsSubmitted(false);
  };

  return (
    <section
      id="partnership"
      className="relative py-24 sm:py-32 bg-[#141414] border-t border-white/5 overflow-hidden"
    >
      {/* Background visual textures */}
      <div className="absolute top-0 right-0 w-[50%] h-[100%] bg-gradient-to-l from-luxury-pink/[0.02] to-transparent pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[10%] w-[400px] h-[400px] rounded-full bg-luxury-pink/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-stretch">
          
          {/* Left Column: Benefits & Storytelling */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 text-luxury-pink">
                <Building size={16} />
                <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
                  Retail Network
                </span>
              </div>

              <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white leading-tight">
                Partner With Inshas
              </h2>

              <p className="text-white/70 font-light leading-relaxed text-base sm:text-lg">
                We actively partner with premium supermarkets, bookstores, gift shops, lifestyle retailers, home décor stores, and online marketplaces across Pakistan. If you are looking to introduce world-class premium lifestyle products to your discerning customers, we'd love to build a profitable, long-term partnership with you.
              </p>

              {/* Verified benefits list */}
              <div className="space-y-3 pt-4">
                <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-semibold block mb-1">
                  Exclusive Partnership Benefits:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {benefits.map((benefit) => (
                    <div key={benefit} className="flex items-center space-x-3 text-white/90 bg-white/[0.01] p-3 rounded-xl border border-white/[0.03]">
                      <div className="w-5 h-5 rounded-full bg-luxury-pink/15 flex items-center justify-center shrink-0 border border-luxury-pink/20">
                        <Check size={12} className="text-luxury-pink font-extrabold" />
                      </div>
                      <span className="text-xs sm:text-sm font-light">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Catalog Download / View Controls */}
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4 pt-6 mt-8">
              <div className="flex items-center space-x-3">
                <FileText className="text-luxury-pink" size={24} />
                <div>
                  <h4 className="font-serif text-sm font-bold text-white">Wholesale Catalog & Pricing sheet</h4>
                  <p className="text-[11px] text-white/40 mt-0.5">Explore retailer pricing structures and order logistics.</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => {
                    setIsCatalogOpen(true);
                    setCatalogPage(1);
                  }}
                  className="flex-1 text-xs uppercase tracking-widest bg-white hover:bg-luxury-pink text-brand-black font-semibold px-6 py-3.5 rounded-full transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer shadow-md hover:-translate-y-0.5"
                >
                  <FileText size={14} />
                  <span>Digital Catalog</span>
                </button>
                <a
                  href={`#`}
                  onClick={(e) => {
                    e.preventDefault();
                    setIsCatalogOpen(true);
                    setCatalogPage(1);
                  }}
                  className="flex-1 text-xs uppercase tracking-widest border border-white/10 hover:border-luxury-pink/50 text-white/80 hover:text-luxury-pink bg-white/5 px-6 py-3.5 rounded-full transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Download size={14} />
                  <span>Download Catalogue</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Application Form */}
          <div className="lg:col-span-6">
            <div className="relative p-8 rounded-[2rem] border border-white/10 bg-[#1a1a1a] shadow-2xl overflow-hidden h-full flex flex-col justify-center">
              {/* Subtle background visual */}
              <div className="absolute top-[-10%] right-[-10%] w-[200px] h-[200px] rounded-full bg-luxury-pink/5 blur-[50px] pointer-events-none" />

              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                  <div className="space-y-1">
                    <h3 className="font-serif text-2xl font-bold text-white">Partnership Application</h3>
                    <p className="text-xs text-white/50">Submit details to request bulk quotation.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs text-white/70">Store or Business Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Al-Fatah Supermarket"
                        value={storeName}
                        onChange={(e) => setStoreName(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs text-white/70">Contact Person Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Haris Mehmood"
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs text-white/70">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="e.g. buyer@store.pk"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs text-white/70">Phone / WhatsApp Number *</label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 03217654321"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs text-white/70">City of Operation *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Karachi"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs text-white/70">Business / Store Type *</label>
                      <select
                        value={storeType}
                        onChange={(e) => setStoreType(e.target.value)}
                        className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                      >
                        <option value="Supermarket">Supermarket</option>
                        <option value="Bookstore">Bookstore / Stationers</option>
                        <option value="Gift Shop">Gift Shop / Gifting agency</option>
                        <option value="Lifestyle Retailer">Lifestyle / Home Decor Boutique</option>
                        <option value="Online Marketplace">Online Marketplace Seller</option>
                        <option value="Other">Other Business</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-white/70">Additional Message (Optional)</label>
                    <textarea
                      placeholder="Tell us about your audience or any specific queries..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={3}
                      className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full text-xs uppercase tracking-widest bg-luxury-pink hover:bg-luxury-pink-dark text-brand-black font-bold py-4 rounded-full transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-brand-black border-t-transparent rounded-full animate-spin" />
                        <span>Sending Proposal...</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>Submit Application</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center space-y-6 relative z-10"
                >
                  <div className="w-16 h-16 rounded-full bg-luxury-pink/15 border border-luxury-pink flex items-center justify-center mx-auto text-luxury-pink animate-pulse">
                    <Building size={28} />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-serif text-2xl font-bold text-white">Application Received!</h3>
                    <p className="text-xs text-white/50">Thank you for expressing interest in partnering with Inshas.</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 text-xs text-left space-y-2 max-w-sm mx-auto">
                    <p className="text-white/60">
                      <strong>Store:</strong> {storeName} ({storeType})
                    </p>
                    <p className="text-white/60">
                      <strong>Representative:</strong> {contactPerson}
                    </p>
                    <p className="text-white/60">
                      <strong>Location:</strong> {city}, Pakistan
                    </p>
                    <p className="text-[10px] text-luxury-pink bg-luxury-pink/5 p-2 rounded border border-luxury-pink/20 font-mono text-center">
                      ✓ wholesale catalogue downloaded to virtual panel
                    </p>
                  </div>

                  {/* Real WhatsApp Forwarding option for faster processing */}
                  <div className="space-y-3 pt-2">
                    <p className="text-[11px] text-white/40 leading-relaxed max-w-sm mx-auto">
                      Forward your business application details directly to our Key Accounts Manager via WhatsApp for a priority bulk pricing quote within 30 minutes!
                    </p>
                    
                    <a
                      href={getWhatsAppPartnerLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-2 text-xs uppercase tracking-widest bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3.5 rounded-full shadow-lg transition-colors w-full max-w-sm"
                    >
                      <MessageSquare size={14} />
                      <span>Forward via WhatsApp</span>
                    </a>

                    <button
                      onClick={resetForm}
                      className="text-xs text-white/40 hover:text-white underline block mx-auto pt-2 focus:outline-none"
                    >
                      Submit Another Application
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* Interactive PDF Wholesale Catalog Viewer Modal */}
      <AnimatePresence>
        {isCatalogOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCatalogOpen(false)}
              className="absolute inset-0 bg-brand-black/90 backdrop-blur-md"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-3xl bg-brand-black border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-10 flex flex-col"
            >
              {/* Top Bar */}
              <div className="flex items-center justify-between p-4 border-b border-white/5 bg-[#161616]">
                <div className="flex items-center space-x-2">
                  <FileText className="text-luxury-pink" size={16} />
                  <span className="font-serif text-xs font-bold text-white tracking-widest uppercase">
                    Inshas Wholesale Catalog — Confidential
                  </span>
                </div>
                <button
                  onClick={() => setIsCatalogOpen(false)}
                  className="p-1 rounded-full hover:bg-white/5 text-white/50 hover:text-white transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Digital Page Canvas */}
              <div className="p-8 sm:p-12 min-h-[400px] flex items-center justify-center bg-radial from-[#1e1e1e] to-brand-black text-center relative overflow-hidden">
                <div className="absolute top-4 right-4 bg-red-500/15 border border-red-500/20 px-3 py-1 rounded text-[8px] tracking-[0.25em] text-red-400 font-mono uppercase">
                  {catalogSlides[catalogPage - 1].badge}
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={catalogPage}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-6 max-w-xl"
                  >
                    <span className="text-[10px] uppercase tracking-[0.38em] text-luxury-pink font-mono block">
                      {catalogSlides[catalogPage - 1].subtitle}
                    </span>
                    <h3 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                      {catalogSlides[catalogPage - 1].title}
                    </h3>
                    <div className="w-12 h-[1px] bg-luxury-pink mx-auto my-4" />
                    <p className="text-xs sm:text-sm uppercase tracking-widest text-white/60 font-medium">
                      {catalogSlides[catalogPage - 1].tagline}
                    </p>
                    <p className="text-sm sm:text-base text-white/80 font-light leading-relaxed whitespace-pre-line bg-white/[0.01] p-6 rounded-xl border border-white/5 text-left font-mono">
                      {catalogSlides[catalogPage - 1].description}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Bottom Catalog Nav Controls */}
              <div className="flex items-center justify-between p-4 border-t border-white/5 bg-[#161616] text-xs">
                <button
                  onClick={handlePrevPage}
                  disabled={catalogPage === 1}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md hover:bg-white/5 text-white/60 hover:text-white disabled:opacity-30 transition-all cursor-pointer"
                >
                  <ChevronLeft size={16} />
                  <span>Prev Page</span>
                </button>
                
                <span className="text-white/40 font-mono">
                  Page <strong className="text-white">{catalogPage}</strong> of {catalogSlides.length}
                </span>

                <button
                  onClick={handleNextPage}
                  disabled={catalogPage === catalogSlides.length}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md hover:bg-white/5 text-white/60 hover:text-white disabled:opacity-30 transition-all cursor-pointer"
                >
                  <span>Next Page</span>
                  <ChevronRight size={16} />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* External modal link hooks */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onCloseModal}
            className="absolute inset-0 bg-brand-black/85 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-xl bg-[#1a1a1a] border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl z-10 p-8"
          >
            <div className="flex justify-between items-center pb-4 border-b border-white/5 mb-6">
              <span className="font-serif text-lg font-bold text-white uppercase tracking-widest flex items-center space-x-2">
                <Building size={16} className="text-luxury-pink" />
                <span>Partner with Inshas</span>
              </span>
              <button onClick={onCloseModal} className="p-1 rounded-full hover:bg-white/5 text-white/50 hover:text-white">
                <X size={20} />
              </button>
            </div>

            {/* Direct Form inside Modal */}
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Store Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Al-Fatah Store"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Contact Person</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Haris Mehmood"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Phone / WhatsApp</label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 03217654321"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">City</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lahore"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-white/40 font-semibold block">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="buyer@store.pk"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full text-xs uppercase tracking-widest bg-luxury-pink hover:bg-luxury-pink-dark text-brand-black font-bold py-4 rounded-full transition-all flex items-center justify-center space-x-2"
                >
                  {isSubmitting ? (
                    <div className="w-4 h-4 border-2 border-brand-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <span>Submit Application</span>
                  )}
                </button>
              </form>
            ) : (
              <div className="text-center space-y-4">
                <Check className="text-luxury-pink mx-auto" size={40} />
                <h4 className="font-serif text-lg font-bold text-white">Application Received!</h4>
                <p className="text-xs text-white/50">Our wholesale business team will review and connect with you shortly.</p>
                <a
                  href={getWhatsAppPartnerLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 text-xs uppercase tracking-widest bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3 rounded-full w-full justify-center"
                >
                  <MessageSquare size={14} />
                  <span>Send direct WhatsApp Application</span>
                </a>
                <button onClick={onCloseModal} className="text-xs text-white/30 underline hover:text-white pt-2">
                  Close Form
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </section>
  );
}
