/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ArrowRight } from "lucide-react";

interface HeaderProps {
  onScrollToSection: (sectionId: string) => void;
  onOpenPartnerModal: () => void;
}

export default function Header({ onScrollToSection, onOpenPartnerModal }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { label: "Home", id: "home" },
    { label: "Products", id: "products" },
    { label: "About", id: "about" },
    { label: "Why Inshas", id: "why-choose" },
    { label: "Retail Partnership", id: "partnership" },
    { label: "FAQ", id: "faq" },
    { label: "Contact", id: "contact" },
  ];

  const handleNavClick = (id: string) => {
    setMobileMenuOpen(false);
    onScrollToSection(id);
  };

  return (
    <>
      <motion.header
        id="app-header"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-500 ${
          isScrolled
            ? "bg-brand-black/85 backdrop-blur-md border-b border-white/5 py-4 shadow-xl"
            : "bg-transparent py-6"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick("home")}
            className="flex flex-col items-start focus:outline-none group cursor-pointer"
          >
            <span className="font-serif text-2xl sm:text-3xl font-bold tracking-[0.25em] text-white transition-all duration-300 group-hover:text-luxury-pink">
              INSHAS
            </span>
            <span className="text-[7px] sm:text-[9px] uppercase tracking-[0.38em] text-white/40 group-hover:text-luxury-pink/60 transition-colors duration-300 -mt-0.5">
              Everyday Elegance
            </span>
          </button>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="text-xs uppercase tracking-widest text-white/70 hover:text-luxury-pink transition-colors cursor-pointer font-medium relative py-1 group"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-luxury-pink transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </nav>

          {/* CTAs */}
          <div className="hidden xl:flex items-center space-x-4">
            <button
              onClick={onOpenPartnerModal}
              className="text-xs uppercase tracking-widest text-white/80 border border-white/20 hover:border-luxury-pink/50 hover:text-luxury-pink px-5 py-2.5 rounded-full transition-all duration-300 cursor-pointer bg-white/5 hover:bg-luxury-pink/5 font-medium"
            >
              Retail Partner
            </button>
            <button
              onClick={() => handleNavClick("products")}
              className="text-xs uppercase tracking-widest bg-luxury-pink hover:bg-luxury-pink-dark text-brand-black px-6 py-2.5 rounded-full transition-all duration-300 shadow-md font-semibold cursor-pointer hover:shadow-luxury-pink/20 hover:-translate-y-0.5"
            >
              Shop Now
            </button>
          </div>

          {/* Mobile & Tablet Toggle */}
          <div className="flex items-center lg:hidden space-x-4">
            <button
              onClick={() => handleNavClick("products")}
              className="text-[10px] uppercase tracking-widest bg-luxury-pink text-brand-black px-4 py-2 rounded-full font-semibold"
            >
              Shop
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white hover:text-luxury-pink transition-colors focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-30 bg-brand-black/98 backdrop-blur-lg pt-28 px-6 pb-8 flex flex-col justify-between lg:hidden"
          >
            <div className="flex flex-col space-y-6">
              {navItems.map((item, index) => (
                <motion.button
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className="text-left font-serif text-2xl text-white/80 hover:text-luxury-pink transition-colors py-1 cursor-pointer flex items-center justify-between group"
                >
                  <span>{item.label}</span>
                  <ArrowRight size={18} className="opacity-0 group-hover:opacity-100 transition-all duration-300 transform -translate-x-2 group-hover:translate-x-0 text-luxury-pink" />
                </motion.button>
              ))}
            </div>

            <div className="flex flex-col space-y-4 mt-8">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenPartnerModal();
                }}
                className="w-full text-center text-xs uppercase tracking-widest text-white border border-white/20 py-4 rounded-full bg-white/5 font-semibold"
              >
                Become a Retail Partner
              </button>
              <button
                onClick={() => handleNavClick("products")}
                className="w-full text-center text-xs uppercase tracking-widest bg-luxury-pink text-brand-black py-4 rounded-full font-semibold shadow-lg"
              >
                Shop Now
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
