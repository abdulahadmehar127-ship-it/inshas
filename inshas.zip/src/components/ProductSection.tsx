/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, Info, ShoppingCart, MessageSquare, Gift, Truck, ShieldCheck, Heart, Sparkles, X, ChevronDown, CheckCircle2 } from "lucide-react";
import { PRODUCTS } from "../data";
import { Product, OrderConfiguration } from "../types";

interface ProductSectionProps {
  onOrderCompleted: (order: OrderConfiguration & { orderId: string; totalPrice: number; productName: string }) => void;
}

export default function ProductSection({ onOrderCompleted }: ProductSectionProps) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeSpecsTab, setActiveSpecsTab] = useState<{ [productId: string]: boolean }>({});
  
  // Customization state for modal
  const [selectedColor, setSelectedColor] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [isGiftWrapped, setIsGiftWrapped] = useState(false);
  const [giftMessage, setGiftMessage] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [lastOrderId, setLastOrderId] = useState("");
  const [lastTotalPrice, setLastTotalPrice] = useState(0);

  const toggleSpecs = (productId: string) => {
    setActiveSpecsTab((prev) => ({
      ...prev,
      [productId]: !prev[productId],
    }));
  };

  const handleOpenOrderModal = (product: Product) => {
    setSelectedProduct(product);
    setSelectedColor(product.colors[0]);
    setQuantity(1);
    setIsGiftWrapped(false);
    setGiftMessage("");
    setCustomerName("");
    setCustomerPhone("");
    setCustomerAddress("");
    setIsSuccess(false);
    setIsSubmitting(false);
  };

  const calculateTotalPrice = (product: Product) => {
    const basePrice = product.estimatedPricePKR * quantity;
    const wrapPrice = isGiftWrapped ? 250 : 0;
    return basePrice + wrapPrice;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    setIsSubmitting(true);

    const orderId = "INS-" + Math.floor(100000 + Math.random() * 900000);
    const totalPrice = calculateTotalPrice(selectedProduct);

    // Simulate luxury API call or processing delay
    setTimeout(() => {
      const orderData: OrderConfiguration & { orderId: string; totalPrice: number; productName: string } = {
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        quantity,
        selectedColor,
        isGiftWrapped,
        giftMessage: isGiftWrapped ? giftMessage : undefined,
        customerName,
        customerPhone,
        customerAddress,
        paymentMethod: "COD",
        orderId,
        totalPrice,
      };

      // Save to local storage for local persistence
      const savedOrders = JSON.parse(localStorage.getItem("inshas_orders") || "[]");
      savedOrders.push(orderData);
      localStorage.setItem("inshas_orders", JSON.stringify(savedOrders));

      setLastOrderId(orderId);
      setLastTotalPrice(totalPrice);
      setIsSubmitting(false);
      setIsSuccess(true);
      onOrderCompleted(orderData);
    }, 1800);
  };

  // Build dynamic real WhatsApp link
  const getWhatsAppLink = () => {
    if (!selectedProduct) return "#";
    const text = `Assalamu Alaikum Inshas! 🌸\n\nI would like to place an order from your website.\n\n*Order Details:*\n• *Order ID:* ${lastOrderId}\n• *Product:* ${selectedProduct.name}\n• *Color:* ${selectedColor}\n• *Quantity:* ${quantity}\n• *Gift Wrapping:* ${isGiftWrapped ? `Yes (Fee: PKR 250)` : "No"}${isGiftWrapped && giftMessage ? `\n• *Gift Note:* "${giftMessage}"` : ""}\n\n*Customer Information:*\n• *Name:* ${customerName}\n• *Phone:* ${customerPhone}\n• *Shipping Address:* ${customerAddress}\n\n*Total Amount:* PKR ${lastTotalPrice.toLocaleString()} (Free Nationwide Shipping)\n*Payment Method:* Cash on Delivery\n\nThank you!`;
    return `https://wa.me/923004971580?text=${encodeURIComponent(text)}`;
  };

  return (
    <section
      id="products"
      className="relative py-24 sm:py-32 bg-brand-black border-t border-white/5 overflow-hidden"
    >
      <div className="absolute top-[30%] left-[-20%] w-[500px] h-[500px] rounded-full bg-luxury-pink/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[-10%] w-[400px] h-[400px] rounded-full bg-white/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-20 sm:mb-28">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 text-luxury-pink mb-4"
          >
            <Sparkles size={14} className="animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-semibold">
              Featured Creations
            </span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white mb-6"
          >
            Designed for Everyday Elegance
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-white/60 font-light text-base sm:text-lg leading-relaxed"
          >
            A curated selection of tactile, beautifully engineered lifestyle essentials that bring premium aesthetic quality and comfort into Pakistani homes.
          </motion.p>
        </div>

        {/* Alternating Products Showcase */}
        <div className="space-y-32 sm:space-y-48">
          {PRODUCTS.map((product, index) => {
            const isEven = index % 2 === 0;
            return (
              <div
                key={product.id}
                className={`grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center`}
              >
                {/* Product Image Column */}
                <motion.div
                  initial={{ opacity: 0, x: isEven ? -40 : 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={`lg:col-span-6 relative group ${isEven ? "lg:order-1" : "lg:order-2"}`}
                >
                  {/* Subtle decorative elements */}
                  <div className="absolute -inset-1 rounded-[2.5rem] bg-gradient-to-tr from-luxury-pink/20 to-white/10 blur-xl opacity-30 group-hover:opacity-60 transition-opacity duration-700 pointer-events-none" />
                  
                  <div className="relative aspect-[4/3] rounded-[2rem] overflow-hidden border border-white/10 bg-brand-black shadow-2xl">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transform scale-100 group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Glossmorphic badge overlay */}
                    {product.badge && (
                      <div className="absolute top-6 left-6 bg-brand-black/75 backdrop-blur-md border border-white/10 px-4 py-1.5 rounded-full text-[10px] tracking-[0.2em] uppercase font-semibold text-luxury-pink shadow-md">
                        {product.badge}
                      </div>
                    )}
                  </div>
                </motion.div>

                {/* Product Info Column */}
                <motion.div
                  initial={{ opacity: 0, x: isEven ? 40 : -40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={`lg:col-span-6 space-y-8 ${isEven ? "lg:order-2" : "lg:order-1"}`}
                >
                  <div className="space-y-4">
                    <span className="text-xs uppercase tracking-[0.25em] text-luxury-pink/80 font-mono font-medium block">
                      {product.tagline}
                    </span>
                    <h3 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
                      {product.name}
                    </h3>
                    <div className="flex items-baseline space-x-3 pt-1">
                      <span className="font-serif text-2xl sm:text-3xl text-white font-medium">
                        {product.price}
                      </span>
                      <span className="text-xs text-white/40 font-mono">
                        (Includes Free Shipping across Pakistan)
                      </span>
                    </div>
                  </div>

                  <p className="text-white/70 font-light leading-relaxed text-base sm:text-lg">
                    {product.description}
                  </p>

                  {/* Feature Lists */}
                  <div className="space-y-3 pt-2">
                    <span className="text-[10px] uppercase tracking-[0.25em] text-white/40 font-semibold block">
                      Key Highlights:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {product.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start space-x-3 text-white/80">
                          <Check size={16} className="text-luxury-pink mt-0.5 shrink-0" />
                          <span className="text-xs sm:text-sm font-light">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Colors & Expandable Specs */}
                  <div className="space-y-4 pt-4 border-t border-white/5">
                    {/* Available Colors display */}
                    <div className="flex items-center space-x-4">
                      <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-semibold">
                        Exclusive Finishes:
                      </span>
                      <div className="flex space-x-2">
                        {product.colors.map((color, idx) => (
                          <span
                            key={idx}
                            title={color}
                            className="text-[11px] bg-white/5 border border-white/10 px-3 py-1 rounded-full text-white/80 hover:border-luxury-pink/40 hover:text-white transition-colors cursor-default"
                          >
                            {color}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Expandable Technical Specs Tab */}
                    <div className="border border-white/10 rounded-xl overflow-hidden bg-white/[0.02] backdrop-blur-sm">
                      <button
                        onClick={() => toggleSpecs(product.id)}
                        className="w-full flex items-center justify-between p-4 text-left text-xs uppercase tracking-widest text-white/70 hover:text-white hover:bg-white/[0.02] transition-colors focus:outline-none"
                      >
                        <span className="flex items-center space-x-2 font-semibold">
                          <Info size={14} className="text-luxury-pink" />
                          <span>Technical Specifications</span>
                        </span>
                        <ChevronDown
                          size={16}
                          className={`transform transition-transform duration-300 ${
                            activeSpecsTab[product.id] ? "rotate-180 text-luxury-pink" : "text-white/40"
                          }`}
                        />
                      </button>

                      <AnimatePresence>
                        {activeSpecsTab[product.id] && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="border-t border-white/5 overflow-hidden"
                          >
                            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 bg-brand-black/40">
                              {Object.entries(product.specs).map(([key, value]) => (
                                <div key={key} className="flex justify-between py-1 border-b border-white/[0.03] text-xs">
                                  <span className="text-white/40 font-light">{key}</span>
                                  <span className="text-white/90 font-medium font-mono text-right">{value}</span>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  {/* Order Button CTA */}
                  <div className="pt-2">
                    <button
                      onClick={() => handleOpenOrderModal(product)}
                      className="w-full sm:w-auto text-xs uppercase tracking-widest bg-white hover:bg-luxury-pink text-brand-black hover:text-brand-black font-bold px-8 py-4 rounded-full transition-all duration-300 shadow-lg flex items-center justify-center space-x-3 cursor-pointer hover:shadow-luxury-pink/20 hover:-translate-y-0.5 group"
                    >
                      <ShoppingCart size={14} className="group-hover:scale-110 transition-transform" />
                      <span>Order Now (COD)</span>
                    </button>
                  </div>

                </motion.div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Order Configuration Drawer/Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Dark glass backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="absolute inset-0 bg-brand-black/85 backdrop-blur-sm"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="relative w-full max-w-2xl bg-[#161616] border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl z-10 max-h-[90vh] flex flex-col"
            >
              {/* Top Bar */}
              <div className="flex items-center justify-between p-6 border-b border-white/5 bg-[#1a1a1a]">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-luxury-pink animate-ping" />
                  <span className="font-serif text-lg font-bold text-white uppercase tracking-widest">
                    Configure Your Order
                  </span>
                </div>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1 rounded-full hover:bg-white/5 text-white/50 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {!isSuccess ? (
                /* Interactive Form Form */
                <form onSubmit={handleSubmitOrder} className="flex-1 overflow-y-auto p-6 space-y-6">
                  {/* Selected Product Summary Box */}
                  <div className="flex items-center space-x-4 bg-white/[0.02] p-4 rounded-xl border border-white/5">
                    <div className="w-20 h-16 rounded-lg overflow-hidden border border-white/10 bg-brand-black">
                      <img
                        src={selectedProduct.image}
                        alt={selectedProduct.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="font-serif text-sm font-bold text-white">{selectedProduct.name}</h4>
                      <p className="text-xs text-luxury-pink mt-0.5">{selectedProduct.tagline}</p>
                      <p className="text-xs text-white/40 font-mono mt-1">{selectedProduct.price} each</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Left Customization Area */}
                    <div className="space-y-5">
                      <h5 className="text-[10px] uppercase tracking-widest text-white/40 font-bold border-b border-white/5 pb-2">
                        1. Personalize Finish
                      </h5>

                      {/* Color Selector Swatches */}
                      <div className="space-y-2">
                        <label className="text-xs text-white/70">Select Premium Finish:</label>
                        <div className="flex flex-wrap gap-2">
                          {selectedProduct.colors.map((color) => (
                            <button
                              key={color}
                              type="button"
                              onClick={() => setSelectedColor(color)}
                              className={`text-xs px-4 py-2 rounded-full border transition-all duration-300 ${
                                selectedColor === color
                                  ? "border-luxury-pink bg-luxury-pink/10 text-luxury-pink font-semibold"
                                  : "border-white/10 hover:border-white/20 text-white/70"
                              }`}
                            >
                              {color}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Quantity Selector */}
                      <div className="space-y-2">
                        <label className="text-xs text-white/70">Select Quantity:</label>
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center border border-white/10 rounded-full overflow-hidden bg-brand-black/40">
                            <button
                              type="button"
                              onClick={() => setQuantity(Math.max(1, quantity - 1))}
                              className="px-4 py-2 hover:bg-white/5 text-white transition-colors"
                            >
                              -
                            </button>
                            <span className="px-4 text-sm font-mono text-white min-w-[2.5rem] text-center">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => setQuantity(quantity + 1)}
                              className="px-4 py-2 hover:bg-white/5 text-white transition-colors"
                            >
                              +
                            </button>
                          </div>
                          <span className="text-[11px] text-white/40">
                            (Great for gifting!)
                          </span>
                        </div>
                      </div>

                      {/* Premium Gift Wrap Checkbox Option */}
                      <div className="p-4 rounded-xl border border-white/5 bg-white/[0.01] space-y-3">
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isGiftWrapped}
                            onChange={(e) => setIsGiftWrapped(e.target.checked)}
                            className="rounded border-white/20 text-luxury-pink focus:ring-luxury-pink focus:ring-offset-brand-black h-4 w-4 bg-brand-black"
                          />
                          <span className="text-xs text-white/90 flex items-center space-x-2">
                            <Gift size={14} className="text-luxury-pink" />
                            <span>Add Luxury Signature Gift Wrap (+ PKR 250)</span>
                          </span>
                        </label>
                        <p className="text-[10px] text-white/40 pl-7 leading-relaxed">
                          Your item is beautifully cocooned in custom tissue, placed in our signature textured gift box, and includes a handwritten note.
                        </p>

                        {isGiftWrapped && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="pt-2 pl-7"
                          >
                            <textarea
                              placeholder="Write your custom gift message here..."
                              value={giftMessage}
                              onChange={(e) => setGiftMessage(e.target.value)}
                              rows={2}
                              className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink placeholder-white/30"
                            />
                          </motion.div>
                        )}
                      </div>
                    </div>

                    {/* Right Shipping Info Area */}
                    <div className="space-y-5">
                      <h5 className="text-[10px] uppercase tracking-widest text-white/40 font-bold border-b border-white/5 pb-2">
                        2. Shipping & Verification
                      </h5>

                      <div className="space-y-4">
                        <div className="space-y-1">
                          <label className="text-xs text-white/70">Full Name *</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Abdullah Khan"
                            value={customerName}
                            onChange={(e) => setCustomerName(e.target.value)}
                            className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs text-white/70">Phone Number *</label>
                          <input
                            type="tel"
                            required
                            placeholder="e.g. 03001234567"
                            value={customerPhone}
                            onChange={(e) => setCustomerPhone(e.target.value)}
                            className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink font-mono"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs text-white/70">Complete Shipping Address *</label>
                          <textarea
                            required
                            placeholder="e.g. House 45-B, Sector Z, DHA Phase 6, Lahore"
                            value={customerAddress}
                            onChange={(e) => setCustomerAddress(e.target.value)}
                            rows={3}
                            className="w-full bg-brand-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-luxury-pink"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Summary & Price Breakdown */}
                  <div className="p-4 rounded-xl bg-[#1b1b1b] border border-white/5 space-y-2.5">
                    <div className="flex justify-between text-xs text-white/60">
                      <span>Subtotal ({quantity}x)</span>
                      <span className="font-mono">PKR {(selectedProduct.estimatedPricePKR * quantity).toLocaleString()}</span>
                    </div>
                    {isGiftWrapped && (
                      <div className="flex justify-between text-xs text-white/60">
                        <span>Signature Gift Wrapping</span>
                        <span className="font-mono">PKR 250</span>
                      </div>
                    )}
                    <div className="flex justify-between text-xs text-white/60">
                      <span className="flex items-center space-x-1">
                        <Truck size={12} className="text-luxury-pink" />
                        <span>Nationwide Delivery</span>
                      </span>
                      <span className="text-luxury-pink font-semibold">FREE</span>
                    </div>
                    <div className="border-t border-white/5 pt-2 flex justify-between text-sm font-bold text-white">
                      <span>Total Amount (payable on delivery)</span>
                      <span className="font-mono text-luxury-pink text-base">
                        PKR {calculateTotalPrice(selectedProduct).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Security/Trust banner */}
                  <div className="flex items-center justify-between px-2 text-[10px] text-white/40">
                    <span className="flex items-center space-x-1">
                      <ShieldCheck size={12} />
                      <span>100% Secure Checkout</span>
                    </span>
                    <span>• Cash on Delivery</span>
                    <span>• 7-Day Exchange</span>
                  </div>

                  {/* Submit buttons */}
                  <div className="pt-4 border-t border-white/5 flex gap-4">
                    <button
                      type="button"
                      onClick={() => setSelectedProduct(null)}
                      className="flex-1 text-xs uppercase tracking-widest border border-white/10 hover:bg-white/5 text-white/80 py-4 rounded-full font-semibold transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-[2] text-xs uppercase tracking-widest bg-luxury-pink hover:bg-luxury-pink-dark text-brand-black font-bold py-4 rounded-full shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-55"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-brand-black border-t-transparent rounded-full animate-spin" />
                          <span>Securing Order...</span>
                        </>
                      ) : (
                        <>
                          <Check size={14} />
                          <span>Confirm Order (COD)</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              ) : (
                /* Success Layout - Prompts to open in WhatsApp for speed confirmation */
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-8 text-center space-y-6 flex-1 overflow-y-auto"
                >
                  <div className="w-16 h-16 rounded-full bg-luxury-pink/10 border border-luxury-pink flex items-center justify-center mx-auto text-luxury-pink animate-bounce">
                    <CheckCircle2 size={32} />
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-serif text-2xl font-bold text-white">Order Booked Successfully!</h4>
                    <p className="text-xs text-white/50">Our team is preparing your premium experience.</p>
                  </div>

                  {/* Order ID and Total summary */}
                  <div className="max-w-md mx-auto p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3 text-left text-xs">
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-white/40">Order Reference</span>
                      <span className="font-mono text-white font-bold tracking-wider">{lastOrderId}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-white/40">Product Selected</span>
                      <span className="text-white font-semibold">{selectedProduct.name} ({selectedColor})</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-white/40">Recipient Name</span>
                      <span className="text-white font-semibold">{customerName}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-white/40">Shipping Destination</span>
                      <span className="text-white font-mono text-right truncate max-w-[180px]">{customerAddress}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-white/40">Total Price Payable (COD)</span>
                      <span className="font-mono text-luxury-pink font-bold">PKR {lastTotalPrice.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Direct WhatsApp Instant Checkout Option - Extremely crucial in PK context */}
                  <div className="p-4 rounded-xl bg-luxury-pink/5 border border-luxury-pink/10 max-w-md mx-auto space-y-3">
                    <h5 className="text-[11px] uppercase tracking-widest text-luxury-pink font-bold flex items-center justify-center space-x-1.5">
                      <MessageSquare size={12} />
                      <span>Verify via WhatsApp for 12-Hour Dispatch</span>
                    </h5>
                    <p className="text-[10px] text-white/60 leading-relaxed">
                      Tap below to send your pre-filled order invoice directly to our official WhatsApp support channel. Verified WhatsApp orders bypass queueing and ship within 12 hours!
                    </p>
                    <a
                      href={getWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-2 text-xs uppercase tracking-widest bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3 rounded-full shadow-lg transition-colors w-full justify-center"
                    >
                      <MessageSquare size={14} />
                      <span>Send Instant WhatsApp Invoice</span>
                    </a>
                  </div>

                  <div className="pt-4 max-w-xs mx-auto">
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="w-full text-xs uppercase tracking-widest border border-white/10 hover:bg-white/5 text-white/50 py-3 rounded-full font-medium transition-colors cursor-pointer"
                    >
                      Return to Store
                    </button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
