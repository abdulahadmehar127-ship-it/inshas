/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ArrowUp, Sparkles, Heart } from "lucide-react";

interface FooterProps {
  onScrollToTop: () => void;
  onScrollToSection: (sectionId: string) => void;
  onOpenPartnerModal: () => void;
}

export default function Footer({ onScrollToTop, onScrollToSection, onOpenPartnerModal }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-brand-black text-white py-16 sm:py-20 border-t border-white/5 overflow-hidden">
      {/* Soft overlay lines */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-white/5">
          
          {/* Column 1: Brand Info */}
          <div className="md:col-span-5 space-y-5">
            <div className="flex flex-col items-start">
              <span className="font-serif text-2xl font-bold tracking-[0.25em] text-white">
                INSHAS
              </span>
              <span className="text-[8px] uppercase tracking-[0.38em] text-luxury-pink font-semibold mt-0.5">
                Everyday Elegance
              </span>
            </div>
            
            <p className="text-white/50 text-xs sm:text-sm font-light max-w-sm leading-relaxed">
              Inshas is a Pakistani premium lifestyle & gifting brand. We combine beautiful, modern, minimalist aesthetics with exceptional build quality to craft daily essentials that elevate your lifestyle.
            </p>

            <div className="flex items-center space-x-2 text-[11px] text-white/40">
              <Sparkles size={12} className="text-luxury-pink animate-pulse" />
              <span>Designed for Everyday Elegance.</span>
            </div>
          </div>

          {/* Column 2: Sitemap Links */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-bold font-mono">
              The Brand
            </h4>
            <div className="flex flex-col space-y-3 text-xs sm:text-sm">
              <button
                onClick={() => onScrollToSection("home")}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                Return to Top
              </button>
              <button
                onClick={() => onScrollToSection("products")}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                Our Creations
              </button>
              <button
                onClick={() => onScrollToSection("about")}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                The Story
              </button>
              <button
                onClick={() => onScrollToSection("faq")}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                Help & FAQ
              </button>
            </div>
          </div>

          {/* Column 3: Corporate Links */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-bold font-mono">
              B2B Partnerships
            </h4>
            <div className="flex flex-col space-y-3 text-xs sm:text-sm">
              <button
                onClick={onOpenPartnerModal}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                Retailer Application
              </button>
              <button
                onClick={onOpenPartnerModal}
                className="text-left text-white/60 hover:text-luxury-pink transition-colors cursor-pointer"
              >
                Download Margin Sheet
              </button>
              <a
                href="mailto:partnerships@inshas.pk"
                className="text-left text-white/60 hover:text-luxury-pink transition-colors"
              >
                partnerships@inshas.pk
              </a>
              <span className="text-[11px] text-white/30">
                Active partners in Karachi, Lahore, Islamabad & more.
              </span>
            </div>
          </div>

        </div>

        {/* Footer Base */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-8 text-[11px] text-white/40 space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-1.5">
            <span>Made with passion & pride in Pakistan</span>
            <Heart size={10} className="text-luxury-pink fill-luxury-pink" />
          </div>

          <div className="flex items-center space-x-4">
            <span>Copyright © {currentYear} Inshas.</span>
            <button
              onClick={onScrollToTop}
              className="flex items-center space-x-1 hover:text-luxury-pink transition-colors group cursor-pointer"
            >
              <span>Back to Top</span>
              <ArrowUp size={12} className="transform group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
