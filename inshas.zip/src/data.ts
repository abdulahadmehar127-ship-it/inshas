/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Review, FAQItem } from "./types";

// Note: These image paths are generated with specific IDs by AI Studio
export const HERO_IMAGE = "/src/assets/images/hero_lifestyle_1784300412556.jpg";

export const PRODUCTS: Product[] = [
  {
    id: "reading-light",
    name: "Rechargeable Reading Light",
    tagline: "Illumination perfected for focus and comfort.",
    description: "Designed for reading, Quran recitation, studying, and quiet late-night contemplation. Its balanced lightweight form blends seamlessly with premium ergonomics to deliver non-flickering, gentle illumination exactly where you need it.",
    price: "PKR 3,450",
    estimatedPricePKR: 3450,
    image: "/src/assets/images/reading_light_1784300429596.jpg",
    features: [
      "3 Light Colors (Warm, Natural, Cool white ambient temp)",
      "Stepless Brightness Control (Smooth glide dimming)",
      "Rechargeable Battery (Up to 40 hours of focused reading)",
      "99-Minute Auto Timer (Fades gently as you drift to sleep)",
      "Eye-Friendly LED Lighting (Filtered natural diffuser panel)",
      "Portable & Lightweight (Durable premium hinge system)"
    ],
    specs: {
      "Battery Capacity": "2000mAh Li-ion",
      "Charging Port": "USB Type-C (Cable included)",
      "Weight": "95 grams",
      "Color Temperature": "3000K - 6500K",
      "Material": "Premium Satin Finish Aluminum & ABS",
      "Hinge Angle": "180° Foldable Dual-Axis"
    },
    colors: ["Satin White", "Champagne Gold", "Cosmic Gray"],
    badge: "Bestseller"
  },
  {
    id: "crystal-lamp",
    name: "Crystal Night Lamp",
    tagline: "A delicate dance of refraction and warmth.",
    description: "A luxury crystal lamp meticulously sculpted to reflect stunning geometric lights and create an instantly warm, elegant atmosphere. It stands as a striking statement piece during the day and a mesmerizing ambient source at night.",
    price: "PKR 4,850",
    estimatedPricePKR: 4850,
    image: "/src/assets/images/crystal_lamp_1784300445917.jpg",
    features: [
      "Premium Precision Crystal Finish (High refraction facet cut)",
      "Rechargeable Cordless Operation (Clean layout without wires)",
      "Soft Ambient Lighting (Generates romantic comforting glow)",
      "Modern Luxury Design (Architectural cylindrical design)",
      "Perfect Gift Choice (Comes in signature premium textured box)"
    ],
    specs: {
      "Battery Life": "Up to 15 hours of constant magic",
      "Lighting Modes": "Warm Amber, Rose Gold, Soft Candlelight",
      "Control Method": "Capacitive Touch sensor top plate",
      "Dimensions": "8.6 in x 3.5 in",
      "Material": "Optical-grade Acrylic Crystal & Brushed Gold base",
      "Charging Port": "Universal USB Type-C"
    },
    colors: ["Reflective Clear", "Golden Amber", "Rose Quartz"],
    badge: "Signature"
  }
];

export const ADVANTAGES = [
  {
    title: "Premium Quality",
    description: "Carefully selected products with exceptional build quality and premium materials that last."
  },
  {
    title: "Elegant Design",
    description: "Modern minimalist aesthetics that complement your space and elevate your personal lifestyle."
  },
  {
    title: "Fast Delivery",
    description: "Reliable and swift nationwide delivery across Pakistan with robust protective packaging."
  },
  {
    title: "Dedicated Support",
    description: "Professional, warm, and highly personalized customer assistance before and after your purchase."
  },
  {
    title: "Thoughtful Gifting",
    description: "Beautiful products and signature unboxing experiences designed to create timeless, memorable moments."
  },
  {
    title: "Trusted Brand",
    description: "Rooted in Pakistan. Committed to strict quality control, absolute transparency, and satisfaction."
  }
];

export const REVIEWS: Review[] = [
  {
    id: "rev-1",
    rating: 5,
    text: "Beautiful quality. The brightness adjustment is amazing, and the light temperature is perfect for reading late at night without straining my eyes.",
    author: "Zainab R.",
    location: "Lahore",
    date: "July 2026"
  },
  {
    id: "rev-2",
    rating: 5,
    text: "Perfect gift for my father. He uses it for Quran recitation every single night. The battery life is impressive, and the packaging was extremely premium.",
    author: "Haris M.",
    location: "Karachi",
    date: "June 2026"
  },
  {
    id: "rev-3",
    rating: 5,
    text: "Ordered the Crystal Lamp. It completely changed the mood of my bedside space. Premium packaging and excellent, fast customer service on WhatsApp.",
    author: "Ayesha K.",
    location: "Islamabad",
    date: "May 2026"
  }
];

export const FAQS: FAQItem[] = [
  {
    id: "faq-1",
    question: "Do you offer Cash on Delivery?",
    answer: "Yes, we offer reliable Cash on Delivery (COD) services all across Pakistan. You can pay securely in cash when the rider delivers the package to your doorstep."
  },
  {
    id: "faq-2",
    question: "Do you deliver across Pakistan?",
    answer: "Absolutely. We deliver nationwide to all major cities and towns in Pakistan, including Lahore, Karachi, Islamabad, Rawalpindi, Peshawar, Faisalabad, Multan, and more. Shipping usually takes 2-4 business days."
  },
  {
    id: "faq-3",
    question: "Do you offer wholesale pricing?",
    answer: "Yes, we actively provide attractive tier-based wholesale pricing and custom solutions for supermarkets, gift shops, bookstores, lifestyle boutiques, corporate orders, and online marketplaces."
  },
  {
    id: "faq-4",
    question: "How can I become a retail partner?",
    answer: "Becoming a partner is quick and simple. Fill out our Retail Partnership form directly on this website, or connect with our partnerships team via WhatsApp at +92-300-INSHAS or email at partnerships@inshas.pk. We will share our catalog and wholesale pricing structure immediately."
  }
];
