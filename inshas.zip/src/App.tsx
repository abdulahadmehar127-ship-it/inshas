/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Check, ShoppingBag, X } from "lucide-react";

import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import ProductSection from "./components/ProductSection";
import WhyChoose from "./components/WhyChoose";
import RetailPartnership from "./components/RetailPartnership";
import ReviewsFAQ from "./components/ReviewsFAQ";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import FloatingActions from "./components/FloatingActions";
import { OrderConfiguration } from "./types";

export default function App() {
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState(false);
  const [activeNotification, setActiveNotification] = useState<{
    orderId: string;
    productName: string;
    customerName: string;
    totalPrice: number;
  } | null>(null);

  // Auto-dismiss custom notifications after 7 seconds
  useEffect(() => {
    if (activeNotification) {
      const timer = setTimeout(() => {
        setActiveNotification(null);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [activeNotification]);

  const handleScrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80; // height of sticky header
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleOrderCompleted = (order: OrderConfiguration & { orderId: string; totalPrice: number; productName: string }) => {
    setActiveNotification({
      orderId: order.orderId,
      productName: order.productName,
      customerName: order.customerName,
      totalPrice: order.totalPrice
    });
  };

  return (
    <div className="relative min-h-screen bg-brand-black text-white font-sans antialiased overflow-x-hidden selection:bg-luxury-pink selection:text-brand-black">
      
      {/* Background ambient lighting accents */}
      <div className="absolute top-0 left-0 w-full h-[50vh] bg-gradient-to-b from-luxury-pink/5 via-transparent to-transparent pointer-events-none z-0" />
      
      {/* Premium Sticky transparent header */}
      <Header
        onScrollToSection={handleScrollToSection}
        onOpenPartnerModal={() => setIsPartnerModalOpen(true)}
      />

      <main className="relative z-10">
        {/* Hero Landing */}
        <Hero
          onScrollToSection={handleScrollToSection}
          onOpenPartnerModal={() => setIsPartnerModalOpen(true)}
        />

        {/* Narrative Craft Story */}
        <About />

        {/* Custom Spotlight Products section */}
        <ProductSection onOrderCompleted={handleOrderCompleted} />

        {/* Brand Promise Section */}
        <WhyChoose />

        {/* Interactive B2B Retail Partnership Portal */}
        <RetailPartnership
          isModalOpen={isPartnerModalOpen}
          onCloseModal={() => setIsPartnerModalOpen(false)}
        />

        {/* Integrated Reviews & Smooth Accordion FAQ */}
        <ReviewsFAQ />

        {/* Channels Hub & Contact Message box */}
        <ContactSection />
      </main>

      {/* Elegant minimalist footer */}
      <Footer
        onScrollToTop={handleScrollToTop}
        onScrollToSection={handleScrollToSection}
        onOpenPartnerModal={() => setIsPartnerModalOpen(true)}
      />

      {/* Interactive Floater Actions: Back-To-Top and WhatsApp Concierge */}
      <FloatingActions
        onScrollToSection={handleScrollToSection}
        onOpenPartnerModal={() => setIsPartnerModalOpen(true)}
      />

      {/* Premium Notification Overlay on order purchase */}
      <AnimatePresence>
        {activeNotification && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            className="fixed bottom-24 left-1/2 transform -translate-x-1/2 z-50 w-[90%] max-w-md bg-brand-black/90 backdrop-blur-md border border-luxury-pink/30 p-5 rounded-2xl shadow-2xl flex items-start space-x-4 pointer-events-auto"
          >
            <div className="w-10 h-10 rounded-full bg-luxury-pink/15 flex items-center justify-center shrink-0 border border-luxury-pink/30 text-luxury-pink">
              <ShoppingBag size={20} />
            </div>

            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-luxury-pink font-semibold flex items-center space-x-1">
                  <Sparkles size={10} className="animate-pulse" />
                  <span>Order Confirmed</span>
                </span>
                <button
                  onClick={() => setActiveNotification(null)}
                  className="text-white/40 hover:text-white transition-colors p-0.5"
                >
                  <X size={14} />
                </button>
              </div>
              <h4 className="font-serif text-sm font-bold text-white">
                Reference: {activeNotification.orderId}
              </h4>
              <p className="text-xs text-white/70 leading-relaxed font-light">
                Congratulations, <strong>{activeNotification.customerName}</strong>! Your order for <strong>{activeNotification.productName}</strong> (PKR {activeNotification.totalPrice.toLocaleString()}) has been booked. Check your WhatsApp to fast-track your shipment!
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
