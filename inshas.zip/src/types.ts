/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: string;
  estimatedPricePKR: number;
  image: string;
  features: string[];
  specs: { [key: string]: string };
  colors: string[];
  badge?: string;
}

export interface Review {
  id: string;
  rating: number;
  text: string;
  author: string;
  location: string;
  date: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface RetailApplication {
  id: string;
  storeName: string;
  contactPerson: string;
  email: string;
  phone: string;
  city: string;
  storeType: string;
  message?: string;
  submittedAt: string;
}

export interface OrderConfiguration {
  productId: string;
  quantity: number;
  selectedColor: string;
  isGiftWrapped: boolean;
  giftMessage?: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  paymentMethod: "COD";
}
